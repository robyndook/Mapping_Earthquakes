// API key
const API_KEY = "pk.eyJ1Ijoicm9ieW5kb29rIiwiYSI6ImNsMTA4cW81azBkOXQzanA5MTZ2amhsMDkifQ.xUpg5YL5VdkjlgXT9jQlbw";
