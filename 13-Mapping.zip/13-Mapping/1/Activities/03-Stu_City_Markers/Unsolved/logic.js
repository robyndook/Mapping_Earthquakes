// Create a map object
var myMap = L.map("map", {
  center: [37.09, -95.71],
  zoom: 5
});

// Add a tile layer
L.tileLayer("https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}", {
  attribution: "© <a href='https://www.mapbox.com/about/maps/'>Mapbox</a> © <a href='http://www.openstreetmap.org/copyright'>OpenStreetMap</a> <strong><a href='https://www.mapbox.com/map-feedback/' target='_blank'>Improve this map</a></strong>",
  tileSize: 512,
  maxZoom: 18,
  zoomOffset: -1,
  id: "mapbox/streets-v11",
  accessToken: API_KEY
}).addTo(myMap);

// City markers

// Add code to create a marker for each city below and add it to the map

// newyork;
// chicago;
// houston;
// la;
// omaha;

var marker = L.marker([40.7128, -74.0059], {
  draggable: true,
  title: "New York City"
}).addTo(myMap);

var marker = L.marker([41.8781, -87.6298], {
  draggable: true,
  title: "Chicago"
}).addTo(myMap);

var marker = L.marker([41.8781, -87.6298], {
  draggable: true,
  title: "Chicago"
}).addTo(myMap);

var marker = L.marker([29.7604, -95.3698], {
  draggable: true,
  title: "Houston"
}).addTo(myMap);

var marker = L.marker([29.7604, -95.3698], {
  draggable: true,
  title: "Houston"
}).addTo(myMap);

var marker = L.marker([34.0522, -118.2437], {
  draggable: true,
  title: "Los Angeles"
}).addTo(myMap);

var marker = L.marker([33.4484, -112.0740], {
  draggable: true,
  title: "Phoenix"
}).addTo(myMap);


// Loop through the cities array and create one marker for each city.
cityData.forEach(function(city) {
  console.log(city)
  L.marker(city.location).addTo(map);
});



// An array containing each city's location, state, and population.
let cities = [{
  location: [40.7128, -74.0059],
  city: "New York City",
  state: "NY",
  population: 8398748
},
{
  location: [41.8781, -87.6298],
  city: "Chicago",
  state: "IL",
  population: 2705994
},
{
  location: [29.7604, -95.3698],
  city: "Houston",
  state: "TX",
  population: 2325502
},
{
  location: [34.0522, -118.2437],
  city: "Los Angeles",
  state: "CA",
  population: 3990456
},
{
  location: [33.4484, -112.0740],
  city: "Phoenix",
  state: "AZ",
  population: 1660272
}
];



// Loop through the cities array and create one marker for each city.
cityData.forEach(function(city) {
  console.log(city)
  L.marker(city.location)
  .bindPopup("<h2>" + city.city + ", " + city.state + "</h2> <hr> <h3>Population " + city.population + "</h3>")
.addTo(Mymap);
});

let cityData = cities;

// // Loop through the cities array and create one marker for each city.
// cities.forEach(function(city) {
//   console.log(city)
//   L.marker(city.location).addTo(map);
// });
// // * Los Angeles
// // * Houston
// // * Omaha
// // * Chicago