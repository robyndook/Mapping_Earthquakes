// Create our initial map object
// Set the longitude, latitude, and the starting zoom level


// Add a tile layer (the background map image) to our map
// We use the addTo method to add objects to our map

