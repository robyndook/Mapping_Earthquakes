# Everyone Do NYC Neighborhoods

* In this activity, you will be building a map of New York City that is broken down by boroughs and neighborhoods. 

* You will first make a basic map of the data, and then color each neighborhood based on the borough.

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.
