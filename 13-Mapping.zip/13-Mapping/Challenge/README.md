# Module 13 | Assignment - Mapping Earthquakes

Use JavaScript’s Leaflet library along with the Mapbox API to create visualizations of earthquake data from the U.S. Geological Survey.
